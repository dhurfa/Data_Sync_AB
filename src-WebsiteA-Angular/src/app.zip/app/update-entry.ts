export class UpdateEntry {
    FirstName : any;
    LastName : any;
    Admission : any;
    PracticingArea : any;
    PracticeLocation : any;


    constructor(){
        this.FirstName = null;
        this.LastName = null;
        this.Admission = 0 ;
        this.PracticingArea = null;
        this.PracticeLocation = null;
    }
}
