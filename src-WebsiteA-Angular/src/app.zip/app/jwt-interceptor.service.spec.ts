import { TestBed } from '@angular/core/testing';

import { JwtInterceptorService } from './jwt-interceptor.service';

describe('JwtInterceptorService', () => {
  let service: JwtInterceptorService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(JwtInterceptorService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('[Logout - Check]', () => {
    let token = "abcdefg";
    let value = "dhurfa";
    localStorage.setItem(token , value);
    let res = localStorage.getItem(token);
    expect(res).toEqual(value);
  });
});
